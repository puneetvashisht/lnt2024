package com.lnt.spring_boot_demo2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootDemo2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
