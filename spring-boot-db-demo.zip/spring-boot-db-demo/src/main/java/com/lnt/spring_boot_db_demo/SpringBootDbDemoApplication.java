package com.lnt.spring_boot_db_demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootDbDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootDbDemoApplication.class, args);
	}

}
