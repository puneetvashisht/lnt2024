package com.lnt.spring_boot_db_demo3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootDbDemo3Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootDbDemo3Application.class, args);
	}

}
