package com.lnt.spring_boot_db_demo3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootDbDemo3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
